document.getElementById("fpage").style.height = screen.height + "px";
